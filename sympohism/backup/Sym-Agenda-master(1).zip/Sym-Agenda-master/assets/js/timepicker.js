jQuery(document).ready(function($) {
    $('.tmepicker1').timepicker({
});
    $('.timepicker2').timepicker({
});
});
