(function($){
	document.getElementById('Event_name').value = "<?php echo $_GET['Event_name'];?>";
	)};